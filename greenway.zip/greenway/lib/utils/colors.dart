import 'package:flutter/material.dart';


Color primaryColor = Color(0xFFE6E6FA);
Color darkPrimaryColor = Color(0xFF734F96);