#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\posio\Documents\flutter_windows_v1.12.13+hotfix.5-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\posio\greenway"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build\ios"
export "FLUTTER_FRAMEWORK_DIR=C:\Users\posio\Documents\flutter_windows_v1.12.13+hotfix.5-stable\flutter\bin\cache\artifacts\engine\ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
