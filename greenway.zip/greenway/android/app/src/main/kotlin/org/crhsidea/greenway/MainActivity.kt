package org.crhsidea.greenway

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
